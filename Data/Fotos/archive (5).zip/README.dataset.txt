# Malaria Detection > 2023-08-04 1:53pm
https://universe.roboflow.com/naslink/malaria-detection-0rrev

Provided by a Roboflow user
License: CC BY 4.0

